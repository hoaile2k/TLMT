System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Config, DataStore, AssetsManager, _dec, _class, _crd, ccclass, property, Observer;

  function _reportPossibleCrUseOfConfig(extras) {
    _reporterNs.report("Config", "./Config", _context.meta, extras);
  }

  function _reportPossibleCrUseOfDataStore(extras) {
    _reporterNs.report("DataStore", "./DataStore", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAssetsManager(extras) {
    _reporterNs.report("AssetsManager", "./AssetsManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      Config = _unresolved_2.Config;
    }, function (_unresolved_3) {
      DataStore = _unresolved_3.DataStore;
    }, function (_unresolved_4) {
      AssetsManager = _unresolved_4.AssetsManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "aa501Rz+atBDZEfOh3p8hzP", "Observer", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Observer", Observer = (_dec = ccclass('Observer'), _dec(_class = class Observer extends Component {
        getConfig() {
          return this.node.getComponent(_crd && Config === void 0 ? (_reportPossibleCrUseOfConfig({
            error: Error()
          }), Config) : Config);
        }

        getDataStore() {
          return this.node.getComponent(_crd && DataStore === void 0 ? (_reportPossibleCrUseOfDataStore({
            error: Error()
          }), DataStore) : DataStore);
        }

        getAssetsManager() {
          return this.node.getComponent(_crd && AssetsManager === void 0 ? (_reportPossibleCrUseOfAssetsManager({
            error: Error()
          }), AssetsManager) : AssetsManager);
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=13e2fc84edfd4fa921d5c809a16c106a91b28538.js.map