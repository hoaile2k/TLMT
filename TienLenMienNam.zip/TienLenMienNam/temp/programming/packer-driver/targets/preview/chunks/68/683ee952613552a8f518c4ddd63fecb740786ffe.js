System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, AssetsDefine, _crd;

  _export("AssetsDefine", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fdb72W8GwVKSoK/uLDPBBGO", "AssetsDefine", undefined);

      _export("AssetsDefine", AssetsDefine = class AssetsDefine {});

      AssetsDefine.MAP_CARD_ASSET = void 0;

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=683ee952613552a8f518c4ddd63fecb740786ffe.js.map