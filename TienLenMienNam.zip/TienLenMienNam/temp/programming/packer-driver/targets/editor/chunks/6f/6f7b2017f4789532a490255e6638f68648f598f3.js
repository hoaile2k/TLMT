System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, io, GameState, _crd;

  function _reportPossibleCrUseOfDirector(extras) {
    _reporterNs.report("Director", "../Base/Director", _context.meta, extras);
  }

  function _reportPossibleCrUseOfio(extras) {
    _reporterNs.report("io", "../libs/socket.io.js", _context.meta, extras);
  }

  _export("GameState", void 0);

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }, function (_unresolved_2) {
      io = _unresolved_2.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "6717dXO9VJM+IgPDj7PBoUr", "GameState", undefined);

      _export("GameState", GameState = class GameState {
        constructor(Director) {
          this.Director = void 0;
          this.Director = Director;
          this.prepareWebSocket("ws://localhost:8080");
        }

        prepareWebSocket(wss) {
          const socket = (_crd && io === void 0 ? (_reportPossibleCrUseOfio({
            error: Error()
          }), io) : io)(wss, {
            transports: ['websocket'] // forces websockets only

          });
          socket.on("connected", data => {
            console.log("Socket msg:", data.msg);
          });
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=6f7b2017f4789532a490255e6638f68648f598f3.js.map