System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _cc, Observer, _dec, _class, _crd, cc, ccclass, property, Subscriber;

  function _reportPossibleCrUseOfObserver(extras) {
    _reporterNs.report("Observer", "./Observer", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc2) {
      _cclegacy = _cc2.cclegacy;
      __checkObsolete__ = _cc2.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc2.__checkObsoleteInNamespace__;
      _cc = _cc2;
    }, function (_unresolved_2) {
      Observer = _unresolved_2.Observer;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "3ea6fwgX7RB1pI1ljZHasPR", "Subscriber", undefined);

      cc = __checkObsoleteInNamespace__(_cc);
      ({
        ccclass,
        property
      } = cc._decorator);

      _export("Subscriber", Subscriber = (_dec = ccclass('Subscriber'), _dec(_class = class Subscriber extends cc.Component {
        constructor(...args) {
          super(...args);
          this._observer = void 0;
        }

        onLoad() {
          this._observer = cc.find("Canvas").getComponentInChildren(_crd && Observer === void 0 ? (_reportPossibleCrUseOfObserver({
            error: Error()
          }), Observer) : Observer);
        }

        getConfig() {
          this._observer.getConfig();
        }

        getAssetsManager() {
          this._observer.getAssetsManager();
        }

        getDataStore() {
          this._observer.getDataStore();
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=31734fd3284508152dd1b08d2be871b4a00e8def.js.map