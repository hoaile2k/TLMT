import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Config')
export class Config extends Component {
    start() {

    }

    update(deltaTime: number) {
        
    }
}

